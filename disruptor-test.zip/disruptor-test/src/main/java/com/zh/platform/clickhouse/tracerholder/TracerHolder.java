package com.zh.platform.clickhouse.tracerholder;

import com.alibaba.ttl.TransmittableThreadLocal;

public class TracerHolder {

    private static TransmittableThreadLocal<Long> transmittableThreadLocal = new TransmittableThreadLocal();

    public static void setId(Long id){
        transmittableThreadLocal.set(id);
    }

    public static Long getId(){
        try {
            return transmittableThreadLocal.get();
        } catch (Exception e) {
            return 0L;
        }
    }
}
