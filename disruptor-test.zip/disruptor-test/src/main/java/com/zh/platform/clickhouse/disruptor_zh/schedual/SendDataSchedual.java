package com.zh.platform.clickhouse.disruptor_zh.schedual;

import com.zh.platform.clickhouse.disruptor_zh.Person;
import com.zh.platform.clickhouse.disruptor_zh.Producer;
import com.zh.platform.clickhouse.disruptor_zh.queue.MyQueue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

@Component
public class SendDataSchedual {

    private static final Logger logger = LoggerFactory.getLogger(SendDataSchedual.class);

    @Resource
    Producer producer;

    static int age = 1;

    @PostConstruct
    public void sendData(){

        logger.info("定时任务开始执行");
        ScheduledExecutorService scheduledExecutorService = Executors.newSingleThreadScheduledExecutor();
        scheduledExecutorService.scheduleAtFixedRate(() -> {
            long start = System.currentTimeMillis();
            for(int i = 0;i < 10;i ++){
                producer.sendData(new Person("阿达",age ++,"男",age * 1000));
            }
            long end = System.currentTimeMillis();
            logger.info("本次消费耗时:" + (end - start) + "ms");

            //验证消费是否有序
            /*logger.info("Queue:{}",MyQueue.queue.poll());
            logger.info("Queue:{}",MyQueue.queue.poll());
            logger.info("Queue:{}",MyQueue.queue.poll());
            logger.info("Queue:{}",MyQueue.queue.poll());
            logger.info("Queue:{}",MyQueue.queue.poll());*/
        },0,10, TimeUnit.SECONDS);
    }

}
