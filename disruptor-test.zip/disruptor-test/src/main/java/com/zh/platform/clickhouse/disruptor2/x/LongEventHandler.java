package com.zh.platform.clickhouse.disruptor2.x;

import com.lmax.disruptor.EventHandler;
import com.lmax.disruptor.WorkHandler;

public class LongEventHandler implements EventHandler<LongEvent> , WorkHandler<LongEvent> {
    @Override
    public void onEvent(LongEvent event, long sequence, boolean endOfBatch) throws Exception {
        System.out.println("Event1:" + Thread.currentThread().getName());
    }

    @Override
    public void onEvent(LongEvent event) throws Exception {
        System.out.println("Event2:" + Thread.currentThread().getName());
    }
}
