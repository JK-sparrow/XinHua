package com.zh.platform.clickhouse.disruptor_zh;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@ToString
@NoArgsConstructor
public class Person {

    String name;
    int age;
    String sex;
    long salary;
}
