package com.zh.platform.clickhouse.disruptor3.x;

import com.lmax.disruptor.RingBuffer;
import com.lmax.disruptor.dsl.Disruptor;
import com.zh.platform.clickhouse.disruptor2.x.LongEvent;

import java.nio.ByteBuffer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LongEventMain {

    public static void main(String[] args) throws InterruptedException {

        ExecutorService executorService = Executors.newCachedThreadPool();

        int buffsize = 1024;

        Disruptor<LongEvent> disruptor = new Disruptor<LongEvent>(LongEvent::new,buffsize,executorService);

        disruptor.handleEventsWith(((event, sequence, endOfBatch) -> System.out.println("Event:" + event.getValue())));

        disruptor.start();

        RingBuffer<LongEvent> ringBuffer = disruptor.getRingBuffer();

        ByteBuffer byteBuffer = ByteBuffer.allocate(8);

        for(long l = 0;true;l ++){
            byteBuffer.putLong(0,l);

            ringBuffer.publishEvent((event, sequence, buffer) -> event.setValue(buffer.getLong(0)),byteBuffer);
            Thread.sleep(1000);
        }
    }
}
