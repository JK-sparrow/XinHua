package com.zh.platform.clickhouse.disruptor_zh;

import com.lmax.disruptor.RingBuffer;
import com.zh.platform.clickhouse.disruptor_zh.queue.MyQueue;
import lombok.AllArgsConstructor;

import javax.annotation.Resource;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;


public class Producer {

    public Producer(RingBuffer<Person> ringBuffer) {
        this.ringBuffer = ringBuffer;
    }

    private RingBuffer<Person> ringBuffer;

    /**
     * 发送数据*/
    public void sendData(Person person){

        //验证消费是否有序
        /*MyQueue.queue.offer(person);*/
        //获取下一个序列
        long sequence = ringBuffer.next();
        //拿到下一个序列容器
        Person nextPerson = ringBuffer.get(sequence);
        //复制
        nextPerson.setName(person.getName());
        nextPerson.setAge(person.getAge());
        nextPerson.setSex(person.getSex());
        nextPerson.setSalary(person.getSalary());

        //放回
        ringBuffer.publish(sequence);
    }
}
