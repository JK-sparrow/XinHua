package com.zh.platform.clickhouse.disruptor_zh.consumer;

import com.lmax.disruptor.WorkHandler;
import com.zh.platform.clickhouse.disruptor_zh.Person;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 不重复消费的消费者*/
public class Consumer implements WorkHandler<Person> {

    private static final Logger logger = LoggerFactory.getLogger(Consumer.class);

    @Override
    public void onEvent(Person event) throws Exception {


        logger.info("当前消费的用户为: {},当前消费的线程为:{}",event.toString(),Thread.currentThread().getName());
    }
}
