package com.zh.platform.clickhouse.disruptor2.x;

import com.lmax.disruptor.RingBuffer;
import com.lmax.disruptor.dsl.Disruptor;
import com.zh.platform.clickhouse.disruptor2.x.LongEvent;
import com.zh.platform.clickhouse.disruptor2.x.LongEventFactory;
import com.zh.platform.clickhouse.disruptor2.x.LongEventHandler;
import com.zh.platform.clickhouse.disruptor2.x.LongEventProducer;

import java.nio.ByteBuffer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LongEventMain {

    public static void main(String[] args) throws InterruptedException {

        ExecutorService pool = Executors.newCachedThreadPool();

        LongEventFactory longEventFactory = new LongEventFactory();

        int buffersize = 1024;

        Disruptor<LongEvent> disruptor = new Disruptor<>(longEventFactory, buffersize, pool);

        Consumer[] consumerses = new Consumer[5];
        for(int i = 0;i < consumerses.length;i ++){
            Consumer consumer = new Consumer();
            consumerses[i] = consumer;
        }
        disruptor.handleEventsWithWorkerPool(consumerses);



        disruptor.start();

        RingBuffer<LongEvent> ringBuffer = disruptor.getRingBuffer();

        LongEventProducer longEventProducer = new LongEventProducer(ringBuffer);

        ByteBuffer byteBuffer = ByteBuffer.allocate(8);


        for(long l = 0;true;l ++){
            byteBuffer.putLong(0,l);
            for(int i = 0;i < 5;i ++){
                longEventProducer.onData(byteBuffer);
            }
            Thread.sleep(1000);
        }
    }
}
