package com.zh.platform.clickhouse.disruptor_zh.consumer;

import com.lmax.disruptor.EventHandler;
import com.zh.platform.clickhouse.disruptor_zh.Person;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 独立消费的消费者*/
public class SingleConsumer implements EventHandler<Person> {

    private static final Logger logger = LoggerFactory.getLogger(SingleConsumer.class);
    @Override
    public void onEvent(Person event, long sequence, boolean endOfBatch) throws Exception {

        logger.info("单个消费者消费{},当前消费线程为:{}",event.toString(),Thread.currentThread().getName());
    }
}
