package com.zh.platform.clickhouse.disruptor2.x;

import com.lmax.disruptor.WorkHandler;
import com.zh.platform.clickhouse.tracerholder.TracerHolder;

public class Consumer implements WorkHandler {
    @Override
    public void onEvent(Object event) throws Exception {
        TracerHolder.setId(123L);

        System.out.println(Thread.currentThread().getName() + ":" + TracerHolder.getId());
    }
}
