package com.zh.platform.clickhouse.disruptor_zh.queue;

import com.zh.platform.clickhouse.disruptor_zh.Person;

import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;

public class MyQueue {

    public static Queue<Person> queue = new LinkedBlockingQueue<>();
}
