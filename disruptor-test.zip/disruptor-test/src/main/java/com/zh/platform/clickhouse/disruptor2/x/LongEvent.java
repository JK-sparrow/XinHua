package com.zh.platform.clickhouse.disruptor2.x;

public class LongEvent {
    public long getValue() {
        return value;
    }

    private long value;

    public void setValue(long value) {
        this.value = value;
    }
}
