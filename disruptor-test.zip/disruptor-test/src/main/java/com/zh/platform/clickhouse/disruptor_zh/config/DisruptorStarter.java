package com.zh.platform.clickhouse.disruptor_zh.config;

import com.lmax.disruptor.BlockingWaitStrategy;
import com.lmax.disruptor.EventFactory;
import com.lmax.disruptor.RingBuffer;
import com.lmax.disruptor.dsl.Disruptor;
import com.lmax.disruptor.dsl.ProducerType;
import com.zh.platform.clickhouse.disruptor_zh.consumer.Consumer;
import com.zh.platform.clickhouse.disruptor_zh.Person;
import com.zh.platform.clickhouse.disruptor_zh.Producer;
import com.zh.platform.clickhouse.disruptor_zh.consumer.SingleConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

@Configuration
public class DisruptorStarter {

    private static final Logger logger = LoggerFactory.getLogger(DisruptorStarter.class);

    @Bean
    public Producer init(){

        logger.info("开始初始化disruptor队列");

        ThreadFactory factory = Executors.defaultThreadFactory();

        EventFactory<Person> eventFactory = Person::new;

        Disruptor<Person> disruptor = new Disruptor<Person>(eventFactory,1024,factory, ProducerType.SINGLE,new BlockingWaitStrategy());

        //创建10个消费者消费数据
        Consumer[] consumers = new Consumer[10];

        for(int i = 0;i < consumers.length;i ++){
            consumers[i] = new Consumer();
        }
        //多个消费者不会重复消费消息
        disruptor.handleEventsWithWorkerPool(consumers);
        //多个消费者会重复消费消息
        disruptor.handleEventsWith(new SingleConsumer());

        RingBuffer<Person> ringBuffer = disruptor.start();

        return new Producer(ringBuffer);

    }
}
