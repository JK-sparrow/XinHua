package com.zh.platform.clickhouse.disruptor2.x;

import com.lmax.disruptor.RingBuffer;

import java.nio.ByteBuffer;

public class LongEventProducer {

    private final RingBuffer<LongEvent> ringBuffer;

    public LongEventProducer(RingBuffer<LongEvent> ringBuffer) {
        this.ringBuffer = ringBuffer;
    }

    public void onData(ByteBuffer bb){

        long sequence = ringBuffer.next();

        try {
            LongEvent longEvent = ringBuffer.get(sequence);
            longEvent.setValue(bb.get(0));
        } finally {
            ringBuffer.publish(sequence);
        }

    }
}
