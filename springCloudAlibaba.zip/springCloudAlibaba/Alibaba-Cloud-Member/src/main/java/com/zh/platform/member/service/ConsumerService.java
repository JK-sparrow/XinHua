package com.zh.platform.member.service;

import com.zh.platform.member.handle.SentinelExceptionHandle;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(value = "alibaba-cloud-provder",fallback = SentinelExceptionHandle.class)
public interface ConsumerService {

    @RequestMapping("/alibaba/provder")
    public String getName(@RequestParam("name") String name);
}
