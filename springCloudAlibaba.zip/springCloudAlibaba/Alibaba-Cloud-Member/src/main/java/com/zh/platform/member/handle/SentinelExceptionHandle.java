package com.zh.platform.member.handle;

import com.zh.platform.member.service.ConsumerService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class SentinelExceptionHandle implements ConsumerService {

    private static final Logger logger = LoggerFactory.getLogger(SentinelExceptionHandle.class);
    @Override
    public String getName(String name) {
        logger.info("Sentinel熔断处理{}","SentinelExceptionHandle");
        return "Sentinel {由于您访问次数过多,已为您进行熔断处理,请稍后再试}";
    }
}
