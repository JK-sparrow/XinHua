package com.zh.download.service.impl;

import com.zh.download.service.DownloadService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.channels.WritableByteChannel;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

@Service
public class DownloadServiceImpl implements DownloadService {

    private static final Logger logger = LoggerFactory.getLogger(DownloadServiceImpl.class);

    @Override
    @Async("asyncThreadPool")
    public void download(HttpServletResponse response) {

        File file = new File("D:\\tools\\docu\\mylogs\\scheduleTest.log.txt");
        logger.info("当前执行任务的线程为:" + Thread.currentThread().getName());
        OutputStream os = null;
        try {

            FileInputStream fileInputStream = new FileInputStream(file);
            //控制web界面弹出路径选择框
            response.setHeader("content-disposition","attachment;filename=" + (file.getName().substring(0,file.getName().indexOf(".")) + ".zip"));
            response.setCharacterEncoding("utf-8");
            os = response.getOutputStream();
            zipAndDownload(fileInputStream,os,file.getName());

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void download1(HttpServletResponse response) {

        File file = new File("D:\\tools\\docu\\mylogs\\scheduleTest.log.txt");
        logger.info("当前执行任务的线程为:" + Thread.currentThread().getName());
        OutputStream os = null;
        try {
            String contentType = Files.probeContentType(Paths.get(file.getAbsolutePath()));
            FileInputStream fileInputStream = new FileInputStream(file);
            response.setContentType(contentType);
            response.setHeader("content-disposition","attachment;filename=" + new String(file.getName().getBytes("utf-8"),"ISO8859-1"));

            WritableByteChannel writableByteChannel = Channels.newChannel(os);
            FileChannel channel = fileInputStream.getChannel();
            channel.transferTo(0,channel.size(),writableByteChannel);
            channel.close();
            os.flush();
            writableByteChannel.close();
            os.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void zipAndDownload(FileInputStream fileInputStream,OutputStream outputStream,String name) throws IOException {

        BufferedInputStream bufferedInputStream = new BufferedInputStream(fileInputStream);
        ZipOutputStream zipOutputStream = new ZipOutputStream(outputStream);
        zipOutputStream.putNextEntry(new ZipEntry(File.separator + name));
        byte[] buffer = new byte[1024 * 10];
        int length;
        while ((length = (bufferedInputStream.read(buffer,0,buffer.length))) != -1){
            zipOutputStream.write(buffer,0,buffer.length);
            zipOutputStream.flush();
        }
        bufferedInputStream.close();
        zipOutputStream.close();
    }
}
