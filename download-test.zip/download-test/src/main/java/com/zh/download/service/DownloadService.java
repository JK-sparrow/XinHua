package com.zh.download.service;

import javax.servlet.http.HttpServletResponse;

public interface DownloadService {

    void download(HttpServletResponse response);

    void download1(HttpServletResponse response);
}
