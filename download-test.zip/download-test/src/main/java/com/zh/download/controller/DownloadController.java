package com.zh.download.controller;

import com.zh.download.service.DownloadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.channels.WritableByteChannel;
import java.nio.file.Files;
import java.nio.file.Paths;

@RestController
public class DownloadController {

    @Autowired
    private DownloadService downloadService;


    @RequestMapping("/download1")
    public String download1(HttpServletRequest request, HttpServletResponse response){

        //调用压缩并下载方法
        downloadService.download(response);

        return "验证成功1";
    }

    @RequestMapping("/download2")
    public String download2(HttpServletRequest request, HttpServletResponse response){

        //调用源文件下载方法
        downloadService.download1(response);

        return "验证成功2";
    }

}
