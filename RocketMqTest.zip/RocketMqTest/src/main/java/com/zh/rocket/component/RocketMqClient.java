package com.zh.rocket.component;

import com.zh.rocket.pojo.OrderPaidEvent;
import org.apache.rocketmq.client.producer.SendCallback;
import org.apache.rocketmq.client.producer.SendResult;
import org.apache.rocketmq.spring.core.RocketMQTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.Serializable;
import java.math.BigDecimal;

@EnableScheduling
@Component
public class RocketMqClient {

    private static final Logger logger = LoggerFactory.getLogger(RocketMqClient.class);

    @Autowired
    private RocketMQTemplate rocketMQTemplate;

    @Scheduled(fixedRate = 5000)
    public void defaultMQProducer(){

        //同步发送
        rocketMQTemplate.convertAndSend("syncTopic","Hello!Rocketmq");
        //发送spring消息
        rocketMQTemplate.send("springTopic", MessageBuilder.withPayload("Hello,i am from spring message!").build());
        //异步发送
        rocketMQTemplate.asyncSend("asyncTopic", new OrderPaidEvent("T_001", new BigDecimal(88.00)), new SendCallback() {
            @Override
            public void onSuccess(SendResult sendResult) {
                logger.info("async onSuccess Result = {}",sendResult);
            }

            @Override
            public void onException(Throwable throwable) {
                logger.info("async onException Throwable = {}",throwable);
            }
        });

        //有序发送消息
        rocketMQTemplate.syncSendOrderly("orderTopic",MessageBuilder.withPayload("HelloWorld").build(),"hashkey");

    }


}


