package com.zh.rocket.component;

import com.zh.rocket.pojo.OrderPaidEvent;
import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
import org.apache.rocketmq.spring.core.RocketMQListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Component
public class RocketMqServer {

    private static final Logger logger = LoggerFactory.getLogger(RocketMqServer.class);

    @RocketMQMessageListener(topic = "syncTopic",consumerGroup = "my-consumer-1")
    @Service
    public class MyConsumer1 implements RocketMQListener<String>{

        @Override
        public void onMessage(String o) {
            logger.info("received syncMessage{}",o);
        }
    }

    @RocketMQMessageListener(topic = "asyncTopic",consumerGroup = "my-consumer-2")
    @Service
    public class MyConsumer2 implements RocketMQListener<OrderPaidEvent>{

        @Override
        public void onMessage(OrderPaidEvent o) {
            logger.info("received asyncMessage{}",o);
        }
    }

    @RocketMQMessageListener(topic = "springTopic",consumerGroup = "my-consumer-3")
    @Service
    public class MyConsumer3 implements RocketMQListener<String>{

        @Override
        public void onMessage(String o) {
            logger.info("received springMessage{}",o);
        }
    }

    @RocketMQMessageListener(topic = "orderTopic",consumerGroup = "my-consumer-4")
    @Service
    public class MyConsumer4 implements RocketMQListener<String>{

        @Override
        public void onMessage(String o) {
            logger.info("received orderMessage{}",o);
        }
    }



}
