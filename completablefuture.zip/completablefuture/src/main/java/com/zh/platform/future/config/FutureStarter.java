package com.zh.platform.future.config;

import com.zh.platform.future.method.*;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.concurrent.ExecutionException;

@Component
public class FutureStarter {

    @PostConstruct
    public void initFuture() throws ExecutionException, InterruptedException {

        Test6.toDo1();
    }
}
