package com.zh.platform.future.method;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;

public class Test4 {

    public static void toDo1() throws ExecutionException, InterruptedException {

        ForkJoinPool pool = new ForkJoinPool();
        //创建异步执行任务 有返回值
        CompletableFuture<Integer> future = CompletableFuture.supplyAsync(() -> {

            System.out.println(Thread.currentThread() + "start time->" + System.currentTimeMillis());

            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            System.out.println(Thread.currentThread() + "end time->" + System.currentTimeMillis());
            return 1;
        },pool);

        //tnenAccept接收入参 但没有返回值
        CompletableFuture<Void> future1 = future.thenAccept((result) -> {

            System.out.println(Thread.currentThread() + "job2 time->" + System.currentTimeMillis());
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println(Thread.currentThread() + "job2 end->" + System.currentTimeMillis());
            //thenRun没有入参也没有返回值
        }).thenRun(() -> {

            System.out.println(Thread.currentThread() + "job3 start->" + System.currentTimeMillis());
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println(Thread.currentThread() + "job3 end->" + System.currentTimeMillis());
        });
        System.out.println(Thread.currentThread() + "main start 1->" + System.currentTimeMillis());
        System.out.println("run res->" + future.get());
        System.out.println(Thread.currentThread() + "main start 2->" + System.currentTimeMillis());
        System.out.println("run res->" + future1.get());
        System.out.println(Thread.currentThread() + "main end->" + System.currentTimeMillis());
    }
}
