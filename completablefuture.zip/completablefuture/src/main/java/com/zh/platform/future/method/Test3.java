package com.zh.platform.future.method;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;

public class Test3 {

    public static void toDo1() throws ExecutionException, InterruptedException {

        ForkJoinPool pool = new ForkJoinPool();
        //创建异步执行任务 有返回值
        CompletableFuture<Integer> future = CompletableFuture.supplyAsync(() -> {

            System.out.println(Thread.currentThread() + "start time->" + System.currentTimeMillis());

            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            System.out.println(Thread.currentThread() + "end time->" + System.currentTimeMillis());
            return 1;
        },pool);

        //thenApply继续由任务1线程执行线程2
        //thenApplyAsync令起一个线程执行线程2
        CompletableFuture<String> apply = future.thenApplyAsync((result) -> {

            System.out.println(Thread.currentThread() + "start time->" + System.currentTimeMillis());
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println(Thread.currentThread() + "end time->" + System.currentTimeMillis());
            return "test" + result;
        });
        System.out.println(Thread.currentThread() + "main start 1->" + System.currentTimeMillis());
        System.out.println("run res->" + future.get());
        System.out.println(Thread.currentThread() + "main start 2->" + System.currentTimeMillis());
        System.out.println("run res->" + apply.get());
        System.out.println(Thread.currentThread() + "main end->" + System.currentTimeMillis());
    }


}
