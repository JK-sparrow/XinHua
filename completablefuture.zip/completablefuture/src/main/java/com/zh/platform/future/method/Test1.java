package com.zh.platform.future.method;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Test1 {

    public static void toDo() throws ExecutionException, InterruptedException {

        ExecutorService executorService = Executors.newSingleThreadExecutor();
        Future<Integer> future = executorService.submit(() -> {

            System.out.println(Thread.currentThread() + "start time->" + System.currentTimeMillis());

            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            System.out.println(Thread.currentThread() + "end time->" + System.currentTimeMillis());
            return 1;
        });
        System.out.println(Thread.currentThread() + "main start->" + System.currentTimeMillis());
        System.out.println("run res->" + future.get());
        System.out.println(Thread.currentThread() + "main end->" + System.currentTimeMillis());
    }
}
