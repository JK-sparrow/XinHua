package com.zh.platform.future.method;

import java.util.concurrent.*;

public class Test2 {

    public static void toDo1() throws ExecutionException, InterruptedException {

        //创建异步执行任务 有返回值
        CompletableFuture<Integer> future = CompletableFuture.supplyAsync(() -> {

            System.out.println(Thread.currentThread() + "start time->" + System.currentTimeMillis());

            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            System.out.println(Thread.currentThread() + "end time->" + System.currentTimeMillis());
            return 1;
        });
        System.out.println(Thread.currentThread() + "main start->" + System.currentTimeMillis());
        System.out.println("run res->" + future.get());
        System.out.println(Thread.currentThread() + "main end->" + System.currentTimeMillis());
    }

    public static void toDo2() throws ExecutionException, InterruptedException {

        //创建异步执行任务 无返回值
        CompletableFuture<Void> future = CompletableFuture.runAsync(() -> {

            System.out.println(Thread.currentThread() + "start time->" + System.currentTimeMillis());

            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            System.out.println(Thread.currentThread() + "end time->" + System.currentTimeMillis());
        });
        System.out.println(Thread.currentThread() + "main start->" + System.currentTimeMillis());
        System.out.println("run res->" + future.get());
        System.out.println(Thread.currentThread() + "main end->" + System.currentTimeMillis());
    }
}
