package com.zh.platform.future.method;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;

public class Test5 {

    public static void toDo1() throws ExecutionException, InterruptedException {

        ForkJoinPool pool = new ForkJoinPool();
        //创建异步执行任务 有返回值
        CompletableFuture<Integer> future = CompletableFuture.supplyAsync(() -> {

            System.out.println(Thread.currentThread() + "start time->" + System.currentTimeMillis());

            try {
                Thread.sleep(2000);
                throw new NullPointerException();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            System.out.println(Thread.currentThread() + "end time->" + System.currentTimeMillis());
            return 1;
        },pool);

        //出现异常走该流程
        CompletableFuture<Integer> exceptionally = future.exceptionally((param) -> {

            System.out.println(Thread.currentThread() + "exception start->" + System.currentTimeMillis());
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("-------------------------------------");
            param.printStackTrace();
            System.out.println(Thread.currentThread() + "exception end->" + System.currentTimeMillis());
            return -1;
        });

        //未出现异常走该流程
        CompletableFuture<Void> future1 = future.thenAccept((param) -> {

            System.out.println(Thread.currentThread() + "future start->" + System.currentTimeMillis());
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("--------------------------------------");
            System.out.println(param);
            System.out.println(Thread.currentThread() + "future end->" + System.currentTimeMillis());
        });
        System.out.println(Thread.currentThread() + "main start 1->" + System.currentTimeMillis());
        System.out.println(exceptionally.get());
        //System.out.println(future1.get());
        System.out.println(Thread.currentThread() + "main end->" + System.currentTimeMillis());
    }
}
