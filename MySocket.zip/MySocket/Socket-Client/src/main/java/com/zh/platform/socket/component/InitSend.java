package com.zh.platform.socket.component;

import com.zh.platform.common.pojo.UploadFile;
import com.zh.platform.socket.handle.FileUploadHandle;
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.codec.serialization.ClassResolvers;
import io.netty.handler.codec.serialization.ObjectDecoder;
import io.netty.handler.codec.serialization.ObjectEncoder;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.SocketChannel;

@Component
public class InitSend {

    private static final String IP = "10.5.32.137";
    private static final int SERVER_PORT = 9090;

    public void send(UploadFile uploadFile){

        /**
         * 传统socket形式*/
        /*try {
            Socket socket = new Socket(IP, SERVER_PORT);
            if(true){
                Socket socket1 = new Socket(IP, SERVER_PORT);
                System.out.println("是");
            }
            OutputStream outputStream = socket.getOutputStream();
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream("123abc".getBytes());
            int length = 0;
            byte[] buff = new byte[1024];
            while ((length = byteArrayInputStream.read(buff)) != -1){
                outputStream.write(buff,0,length);
            }
            outputStream.flush();
            byteArrayInputStream.close();
            outputStream.close();
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }*/

        /**
         * nio channel实现*/

        //打开通道
        /*try {
            SocketChannel client = SocketChannel.open();
            //连接服务器
            client.connect(new InetSocketAddress(IP,SERVER_PORT));
            System.out.println("连接服务器成功");
            FileInputStream fileInputStream = new FileInputStream("C:\\Users\\ywjk\\Desktop\\Netty-transfer-File\\form\\WeChatSetup.exe");
            //创建文件流通道 从硬盘到内存
            FileChannel inputStreamChannel = fileInputStream.getChannel();
            //循环读取到内存中
            ByteBuffer buffer = ByteBuffer.allocate(1024);
            int length = 0;
            long startTime = System.currentTimeMillis();
            while ((length = inputStreamChannel.read(buffer)) != -1){
                buffer.clear();
                int len = client.write(buffer);
                System.out.println("写入数据长度:" + len);
                buffer.flip();
            }
            client.close();
            fileInputStream.close();
            long endTime = System.currentTimeMillis();
            System.out.println("发送文件耗时:" + (endTime - startTime));

        } catch (IOException e) {
            e.printStackTrace();
        }*/

        /**
         * netty框架实现*/

        NioEventLoopGroup group = new NioEventLoopGroup();

        Bootstrap bootstrap = new Bootstrap();
        bootstrap.group(group).channel(NioSocketChannel.class).option(ChannelOption.TCP_NODELAY,true).handler(new ChannelInitializer<Channel>() {
            @Override
            protected void initChannel(Channel channel) throws Exception {
                channel.pipeline().addLast(new ObjectEncoder());//编码自动序列化
                channel.pipeline().addLast(new ObjectDecoder(ClassResolvers.weakCachingConcurrentResolver(null)));//解码序列化
                channel.pipeline().addLast(new FileUploadHandle(uploadFile));
            }
        });
        try {
            ChannelFuture future = bootstrap.connect(IP, SERVER_PORT).sync();
            future.channel().closeFuture().sync();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            group.shutdownGracefully();
        }
    }

    public static void main(String[] args) {

        UploadFile uploadFile = new UploadFile();
        uploadFile.setFile(new File("C:\\Users\\ywjk\\Desktop\\Netty-transfer-File\\form\\WeChatSetup.exe"));
        uploadFile.setFileName("Zchat.exe");
        new InitSend().send(uploadFile);
    }
}
