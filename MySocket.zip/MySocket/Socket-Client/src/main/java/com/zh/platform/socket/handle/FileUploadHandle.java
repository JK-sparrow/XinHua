package com.zh.platform.socket.handle;

import com.zh.platform.common.pojo.UploadFile;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;

import java.io.RandomAccessFile;

public class FileUploadHandle extends ChannelInboundHandlerAdapter {

    //记录每次读取长度
    private int byteRead;
    private volatile int start;
    //分段读取文件长度
    private volatile int lastLength;
    public RandomAccessFile randomAccessFile;
    private UploadFile uploadFile;

    public FileUploadHandle(UploadFile uploadFile) {
        if(uploadFile.getFile().exists()){
            if(!uploadFile.getFile().isFile()){
                System.out.println("it is not a file !!!");
            }
        }else {
            System.out.println("file not exist !!!");
        }
        this.uploadFile = uploadFile;
    }

    /**
     * 客户端启动执行*/
    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
        //只读 封装文件类型
        randomAccessFile = new RandomAccessFile(uploadFile.getFile(),"r");
        //将文件记录指针定位到开始位置
        randomAccessFile.seek(uploadFile.getStartPos());
        //每次读取文件长度1/10
        lastLength = (int)randomAccessFile.length() / 10;
        //设置缓冲区大小
        byte[] buff = new byte[lastLength];
        //读写文件
        if ((byteRead = randomAccessFile.read(buff)) != -1){
            uploadFile.setEndPos(byteRead);
            uploadFile.setBuff(buff);
            ctx.writeAndFlush(uploadFile);
        }else {
            System.out.println("客户端主动发送-文件已读完");
        }

    }

    /**
     * 接收服务端返回的数据并发送给服务端所需数据*/

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        if(msg instanceof Integer){
            //获取文件分片初始位置
            start = (int)msg;
            if(start != -1){
                randomAccessFile = new RandomAccessFile(uploadFile.getFile(),"r");
                //从指定位置开始读
                randomAccessFile.seek(start);
                System.out.println("块长度:" + randomAccessFile.length() / 10);
                //剩余长度
                System.out.println("长度:" + (randomAccessFile.length() - start));
                //剩余长度
                int a = (int)randomAccessFile.length() - start;
                //块长度
                int b = (int)randomAccessFile.length() / 10;
                //如剩余长度不足块长度 修改缓冲区大小为剩余长度
                if(a < b) lastLength = a;
                byte[] buff = new byte[lastLength];
                if((byteRead = randomAccessFile.read(buff)) != -1 && randomAccessFile.length() - start > 0){
                    uploadFile.setEndPos(byteRead);
                    uploadFile.setBuff(buff);
                    //循环按块发送文件
                    ctx.writeAndFlush(uploadFile);
                }else {
                    randomAccessFile.close();
                    ctx.close();
                    System.out.println("文件已经读完");
                }
            }
        }
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        cause.printStackTrace();
        ctx.close();
    }
}
