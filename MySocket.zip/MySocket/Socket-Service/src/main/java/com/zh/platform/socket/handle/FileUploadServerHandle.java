package com.zh.platform.socket.handle;

import com.zh.platform.common.pojo.UploadFile;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;

import java.io.File;
import java.io.RandomAccessFile;

public class FileUploadServerHandle extends ChannelInboundHandlerAdapter {

    private int byteRead;
    private volatile int start = 0;
    private static final String FILE_PATH = "C:\\Users\\ywjk\\Desktop\\Netty-transfer-File\\to";

    /**
     * 对客户端发送来的数据进行处理并返回结果给客户端*/
    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        if(msg instanceof UploadFile){
            UploadFile file = (UploadFile) msg;
            //获取缓冲区
            byte[] buff = file.getBuff();
            //获取文件长度
            byteRead = file.getEndPos();
            //获取文件名
            String fileName = file.getFileName();
            //拼接输出文件路径
            File toFile = new File(FILE_PATH + File.separator + fileName);
            //封装文件 读写
            RandomAccessFile rw = new RandomAccessFile(toFile, "rw");
            rw.seek(start);
            rw.write(buff);
            //更新start位置
            start = start + byteRead;
            if(byteRead > 0){
                //返回给客户端当前已读到位置 等待客户端发送该位置后的文件分片
                ctx.writeAndFlush(start);
            }else {
                rw.close();
                ctx.close();
            }
        }

    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        cause.printStackTrace();
        ctx.close();
    }
}

