package com.zh.platform.socket.component;

import com.zh.platform.socket.handle.FileUploadServerHandle;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.codec.serialization.ClassResolvers;
import io.netty.handler.codec.serialization.ObjectDecoder;
import io.netty.handler.codec.serialization.ObjectEncoder;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;

@Component
public class InitAccept {

    private static final int SERVER_PORT = 9090;

    @PostConstruct
    public void accept(){

        /**
         * 传统socket形式*/
        /*InputStream inputStream = null;
        try {
            ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
            while (true){
                System.out.println("===等待接收数据===");
                Socket socket = serverSocket.accept();
                System.out.println("IP:" + socket.getInetAddress() + "已连接");
                inputStream = socket.getInputStream();
                StringBuilder sb = new StringBuilder();
                int length = 0;
                byte[] buff = new byte[1024];
                while ((length = inputStream.read(buff)) != -1){
                    sb.append(new String(buff));
                }
                System.out.println(sb.toString());
                inputStream.close();
                System.out.println("===数据处理完成===");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }*/

        /**
         * nio channel实现*/
        //打开服务器通道
        /*try {
            ServerSocketChannel socketChannel = ServerSocketChannel.open();
            //绑定端口号
            socketChannel.bind(new InetSocketAddress(SERVER_PORT));
            System.out.println("连接客户端成功");
            FileOutputStream outputStream = new FileOutputStream("C:\\Users\\ywjk\\Desktop\\Netty-transfer-File\\to\\WeChatSetup.exe");
            //创建由内存读到硬盘的通道
            FileChannel fileChannel = outputStream.getChannel();

            //阻塞连接
            socketChannel.configureBlocking(true);
            //服务端接收客户端后给返回值 后面靠返回值操作
            long startTime = System.currentTimeMillis();
            SocketChannel accept = socketChannel.accept();
            System.out.println("连接完成");

            ByteBuffer buffer = ByteBuffer.allocate(1024);
            int length = 0;
            while ((length = accept.read(buffer)) != -1){
                buffer.clear();
                fileChannel.write(buffer);
                buffer.flip();
            }
            socketChannel.close();
            fileChannel.close();
            outputStream.close();
            long endTime = System.currentTimeMillis();
            System.out.println("接收文件耗时:" + (endTime - startTime));

        } catch (IOException e) {
            e.printStackTrace();
        }*/

        /**
         * netty框架实现*/

        //管理线程 负责接收客户端请求 后续交给工作线程处理 通常是单线程
        NioEventLoopGroup bossGroup = new NioEventLoopGroup();
        //工作线程 io等操作
        NioEventLoopGroup workerGroup = new NioEventLoopGroup();

        ServerBootstrap serverBootstrap = new ServerBootstrap();

        serverBootstrap.group(bossGroup,workerGroup)
                .channel(NioServerSocketChannel.class)
                .option(ChannelOption.SO_BACKLOG,1024)
                .childHandler(new ChannelInitializer<Channel>() {
                    @Override
                    protected void initChannel(Channel channel) throws Exception {
                        channel.pipeline().addLast(new ObjectEncoder());
                        channel.pipeline().addLast(new ObjectDecoder(Integer.MAX_VALUE, ClassResolvers.weakCachingConcurrentResolver(null)));
                        channel.pipeline().addLast(new FileUploadServerHandle());
                    }
                });
        try {
            ChannelFuture future = serverBootstrap.bind(SERVER_PORT).sync();
            future.channel().closeFuture().sync();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            bossGroup.shutdownGracefully();
            workerGroup.shutdownGracefully();
        }
    }
}
