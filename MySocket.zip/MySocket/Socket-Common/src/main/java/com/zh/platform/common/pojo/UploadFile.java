package com.zh.platform.common.pojo;

import lombok.Data;

import java.io.File;
import java.io.Serializable;

/**
 * 用于统计文件上传进度*/
@Data
public class UploadFile implements Serializable {

    private static final long serialVersionUID = 1810534282550882748L;

    private File file;

    private String fileName;

    private int startPos;

    private byte[] buff;

    private int endPos;

}
