package com.zh.platform.worker;

import com.zh.platform.worker.udp.UdpServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
@Component
public class Starter {

    private static final Logger logger = LoggerFactory.getLogger(Starter.class);
    @Resource
    private UdpServer udpServer;

    @PostConstruct
    public void start(){
        logger.info("netty监听服务已开启");
        new Thread(() -> {
            //开启服务监听
            udpServer.startServer();
        }).start();
    }
}
