package com.zh.platform.worker.controller;

import com.alibaba.fastjson.JSON;
import com.zh.platform.common.model.TracerData;
import com.zh.platform.common.utils.ProtostuffUtils;
import com.zh.platform.common.utils.ZstdUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@RestController
@RequestMapping("/big")
public class BigTracerController {

    private static final Logger logger = LoggerFactory.getLogger(BigTracerController.class);
    @RequestMapping("/receive")
    public String receiveBigTracer(@RequestParam("data")MultipartFile file){

        try {
            byte[] bytes = file.getBytes();
            //todo 个人测试
            byte[] decompressBytes = ZstdUtils.decompressBytes(bytes);
            TracerData data = ProtostuffUtils.deserialize(decompressBytes, TracerData.class);
            System.out.println("BigTracerController_28: 当前接收到的大数据包为" + data.toString());
            System.out.println("==================" + JSON.toJSON(data.getTracerBeanList().get(0).getTracerObject()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "ok";
    }

}
