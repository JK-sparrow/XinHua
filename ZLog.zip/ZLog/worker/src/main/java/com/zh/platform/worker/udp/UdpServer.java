package com.zh.platform.worker.udp;

import com.zh.platform.common.model.TracerData;
import com.zh.platform.common.utils.ProtostuffUtils;
import com.zh.platform.common.utils.ZstdUtils;
import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.DatagramChannel;
import io.netty.channel.socket.DatagramPacket;
import io.netty.channel.socket.nio.NioDatagramChannel;
import io.netty.handler.codec.MessageToMessageDecoder;
import io.protostuff.ProtostuffIOUtil;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class UdpServer {

    /**
     * 启动server监听器*/


    public void startServer(){

        //1.NioEventLoopGroup是执行者
        NioEventLoopGroup group = new NioEventLoopGroup(1);
        //2.启动器
        Bootstrap bootstrap = new Bootstrap();
        //3.配置启动器
        bootstrap.group(group)                      //3.1指定group
                .channel(NioDatagramChannel.class)  //3.2指定channel
                .option(ChannelOption.RCVBUF_ALLOCATOR,new FixedRecvByteBufAllocator(65535))
                .handler(new ChannelInitializer<DatagramChannel>() {
                    @Override
                    protected void initChannel(DatagramChannel datagramChannel) throws Exception {
                        //3.4在pipeline中加入编码器和解码器
                        datagramChannel.pipeline().addLast(new TracerBeanDecoder());
                    }
                });
        //4.bind到一个端口并返回一个channel 这个端口就是udp监听端口
        try {
            Channel channel = bootstrap.bind(9999).sync().channel();
            //5.等待channel close
            channel.closeFuture().sync();

            //6.关闭group
            group.shutdownGracefully();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * 解码器 解析客户端发送来的消息*/
    private class TracerBeanDecoder extends MessageToMessageDecoder<DatagramPacket>{

        @Override
        protected void decode(ChannelHandlerContext channelHandlerContext, DatagramPacket datagramPacket, List<Object> list) throws Exception {

            ByteBuf buf = datagramPacket.content();
            byte[] bytes = new byte[buf.readableBytes()];
            buf.readBytes(bytes);
            //todo 个人测试
            byte[] decompressBytes = ZstdUtils.decompressBytes(bytes);
            TracerData tracerData = ProtostuffUtils.deserialize(decompressBytes, TracerData.class);
            System.out.println("UdpServer_67: 当前接收到的udp数据包为 " + tracerData.toString());

        }
    }
}


