package com.zh.config;


import com.zh.TracerClientStarter;
import com.zh.filter.UserFilter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;
import javax.servlet.Filter;

@Configuration
public class DemoConfig {

    private static final Logger logger = LoggerFactory.getLogger(DemoConfig.class);

    @Value("${config.server}")
    private String etcdServer;

    @PostConstruct
    public void begin(){

        logger.info("创建etcd工厂");
        TracerClientStarter tracerClientStarter = new TracerClientStarter.Builder()
                .setAppName("localhost2")
                .setEtcdServer(etcdServer)
                .build();
        tracerClientStarter.startPipeline();
    }

    @Bean
    public FilterRegistrationBean urlFilter(){

        FilterRegistrationBean<Filter> filterFilterRegistrationBean = new FilterRegistrationBean<>();

        UserFilter userFilter = new UserFilter();
        filterFilterRegistrationBean.setFilter(userFilter);
        filterFilterRegistrationBean.addUrlPatterns("/*");
        filterFilterRegistrationBean.setName("userTraceFilter");
        filterFilterRegistrationBean.setOrder(1);
        return filterFilterRegistrationBean;
    }
}
