package com.zh.controller;


import com.zh.config.tracerholder.TracerHolder;
import com.zh.platform.common.model.TracerBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.concurrent.Executors;

@RestController
public class ClientDemoController {

    private static final Logger logger = LoggerFactory.getLogger("RequestLog");

    @RequestMapping("/client")
    public Object test(){
        TracerBean tracerBean = new TracerBean();
        tracerBean.setTracerId("123");

        System.out.println("controller19:" + Thread.currentThread().getName());
        logger.info("哈哈哈哈哈");
        return tracerBean;
    }
}
