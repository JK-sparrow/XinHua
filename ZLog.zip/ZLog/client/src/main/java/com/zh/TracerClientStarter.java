package com.zh;

import com.zh.config.etcd.EtcdConfigFactory;
import com.zh.etcd.EtcdStarter;
import com.zh.udp.HttpSender;
import com.zh.udp.UdpClient;
import com.zh.udp.UdpSender;

public class TracerClientStarter {

    /**
     * etcd地址*/
    private String etcdServer;

    public TracerClientStarter(String appName) {

        if(appName == null){
            throw new NullPointerException("appName can not be null");
        }
        Context.APP_NAME = appName;
    }

    public static class Builder{

        private String appName;
        private String etcdServer;

        public Builder setAppName(String appName) {
            this.appName = appName;
            return this;
        }

        public Builder setEtcdServer(String etcdServer) {
            this.etcdServer = etcdServer;
            return this;
        }

        public TracerClientStarter build(){
            TracerClientStarter tracerClientStarter = new TracerClientStarter(appName);
            tracerClientStarter.etcdServer = etcdServer;
            return tracerClientStarter;
        }
    }

    /**
     * 启动监听etcd*/
    public void startPipeline(){

        //配置configcenter
        EtcdConfigFactory.buildConfigCenter(etcdServer);

        EtcdStarter etcdStarter = new EtcdStarter();

        etcdStarter.start();

        UdpClient udpClient = new UdpClient();
        udpClient.start();

        //开启发送
        UdpSender.upLoadToWorker();

        //开启大对象http发送
        HttpSender.upLoadToWorker();
    }
}
