package com.zh.etcd;

import com.alibaba.fastjson.JSON;
import com.google.protobuf.ByteString;
import com.ibm.etcd.api.KeyValue;
import com.ibm.etcd.api.RangeResponse;
import com.ibm.etcd.client.EtcdClient;
import com.ibm.etcd.client.kv.KvClient;
import com.zh.Context;
import com.zh.config.IConfigCenter;
import com.zh.config.etcd.EtcdConfigFactory;
import com.zh.config.etcd.JdEtcdClient;

import com.zh.constant.Constant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.CollectionUtils;
import worker.WorkerInfoHolder;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class EtcdStarter {

    private static final Logger logger = LoggerFactory.getLogger(EtcdStarter.class);

    public void start(){
        fetchWorkerInfo();
    }
    /**
     * 每隔30s拉取worker信息*/
    private void fetchWorkerInfo(){
        ScheduledExecutorService scheduledExecutorService = Executors.newSingleThreadScheduledExecutor();
        scheduledExecutorService.scheduleAtFixedRate(() -> {
            logger.info("try to connetc etcd and fetch worker info;");
            logger.error("test");
            fetch();
                },0,30, TimeUnit.SECONDS);
    }

    /**
     * 从配置中心获取worker的ip合集*/
    private void fetch(){

        IConfigCenter iConfigCenter = EtcdConfigFactory.configCenter();
        //获取所有worker的ip
        List<KeyValue> list = null;
        if(CollectionUtils.isEmpty(list)){
            list = iConfigCenter.getPrefix(Constant.WORKER_PATH + Context.APP_NAME);
        }
        logger.info("获取到的ip列表为: " + list.toString());

        //全是空 给个警告
        if(CollectionUtils.isEmpty(list)){
            logger.warn("very important warn!!! workers ip info is null");
        }

        List<String> address = new ArrayList<>();
        if(list != null){
            for (KeyValue keyValue : list) {
                address.add(keyValue.getValue().toStringUtf8());
            }
        }

        //将对应worker保存下来
        WorkerInfoHolder.mergeAndConnetcNew(address);
    }
}
