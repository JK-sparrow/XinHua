package com.zh.udp;

import com.zh.Context;
import com.zh.constant.Constant;
import com.zh.platform.common.model.TracerData;
import com.zh.platform.common.utils.ProtostuffUtils;
import com.zh.platform.common.utils.ZstdUtils;
import com.zh.utils.AsyncPool;
import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.DatagramPacket;
import io.netty.channel.socket.nio.NioDatagramChannel;
import io.netty.handler.codec.MessageToMessageEncoder;
import worker.WorkerInfoHolder;

import java.net.InetSocketAddress;
import java.util.List;

public class UdpClient {

    /**
     * 大日志超过60000行*/
    private static final long COMPRESS_BYTES_LENGTH = 60000L;

    /**
     * 启动udp客户端*/
    public void start(){
        AsyncPool.asyncDo(this::startUp);
    }

    private void startUp(){

        //NioEventLoopGroup是执行者
        NioEventLoopGroup group = new NioEventLoopGroup();
        //启动器
        Bootstrap bootstrap = new Bootstrap();
        //配置启动器
        bootstrap.group(group)                                              //指定group
                .channel(NioDatagramChannel.class)                          //指定channel
                .handler(new ChannelInitializer<NioDatagramChannel>() {
                    //在pipeline加入编码器和解码器 用来处理返回的消息
                    @Override
                    protected void initChannel(NioDatagramChannel nioDatagramChannel) throws Exception {
                        nioDatagramChannel.pipeline().addLast(new MyUdpEncoder());
                    }
                });
        //bind 并返回一个channel
        try {
            Channel channel = bootstrap.bind(8888).sync().channel();
            Context.CHANNEL = channel;
            //等待channel的close
            channel.closeFuture().sync();
            //关闭group
            group.shutdownGracefully();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }


    /**
     * 编码器 将要发送的消息(此处为string)封装到一个datagramPacket*/
    private static class MyUdpEncoder extends MessageToMessageEncoder<TracerData>{

        @Override
        protected void encode(ChannelHandlerContext channelHandlerContext, TracerData tracerData, List<Object> list) throws Exception {

            //序列化
            byte[] serialize = ProtostuffUtils.serialize(tracerData);
            //压缩
            byte[] compress = ZstdUtils.compress(serialize);

            //判断压缩完是否过大 过大走http接口请求worker
            //if(compress.length >= COMPRESS_BYTES_LENGTH){
            if(compress.length >= 0){

                //放入发okhttp的队列
                HttpSender.offerBean(compress);

                //return;
            }

            ByteBuf buffer = channelHandlerContext.alloc().buffer(compress.length);
            buffer.writeBytes(compress);

            String s = WorkerInfoHolder.chooseWorker();
            if(s == null) {
                return;
            }
            String[] ipPort = s.split(Constant.SPLITER);
            //发往worker的ip
            InetSocketAddress inetSocketAddress = new InetSocketAddress(ipPort[0], Integer.parseInt(ipPort[1]));
            DatagramPacket datagramPacket = new DatagramPacket(buffer, inetSocketAddress);
            list.add(datagramPacket);
        }
    }
}
