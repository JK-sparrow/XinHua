package com.zh.config.tracerholder;


import com.alibaba.ttl.TransmittableThreadLocal;

/**
 * 用于在线程池间传递tracerid*/
public class TracerHolder {

    private static TransmittableThreadLocal<Long> threadLocal = new TransmittableThreadLocal<>();

    /**
     * 设置tracerid到线程里*/
    public static void serTracerId(long tracerid){
        threadLocal.set(tracerid);
    }

    /**
     * 没有则设置一个*/
    public static long getTracerId(){
        try {
            return threadLocal.get();
        } catch (Exception e) {
            return 0L;
        }
    }
}
