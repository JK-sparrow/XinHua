package com.zh.utils;

import com.google.common.base.Preconditions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;

public class SnowFlakeGenerateIdWorker {


    private static final Logger logger = LoggerFactory.getLogger(SnowFlakeGenerateIdWorker.class);
    /**
     * 开始时间戳*/
    private static final long EPOCH;

    /**
     * 序列id所占位数*/
    private static final long SEQUENCE_BITS = 6L;

    /**
     * 机器id所占位数*/
    private static final long WORKER_ID_BITS = 10L;

    /**
     * 序列id最大取值*/
    private static final long SEQUENCE_MASK = -1 ^ (-1 << SEQUENCE_BITS);

    /**
     * 机器id最大取值*/
    private static final long WORKER_ID_MAX_VALUE = -1 ^(-1 << WORKER_ID_BITS);

    /**
     * 机器id左移位数*/
    private static final long WORKER_ID_LEFT_SHIFT_BITS = 6L;

    /**
     * 时间戳左移位数*/
    private static final long TIMESTAMP_LEFT_SHIFT_BITS = SEQUENCE_BITS + WORKER_ID_BITS;

    private static long workerId;

    private static long lastTime;

    private static long sequence;

    static {
        Calendar instance = Calendar.getInstance();
        instance.set(2017,Calendar.APRIL,1);
        instance.set(Calendar.HOUR_OF_DAY,0);
        instance.set(Calendar.MILLISECOND,0);
        instance.set(Calendar.SECOND,0);
        instance.set(Calendar.MILLISECOND,0);
        EPOCH = instance.getTimeInMillis();
        initWorkerId();
    }

    public static void main(String[] args) {
        /**根据本机ip计算出机器id*/
        for(int i = 0;i < 5;i ++){
            long res = nextId();
            System.out.println(res);
            System.out.println(Long.toBinaryString(res));
            System.out.println(Long.toBinaryString(res).length());
            System.out.println(Long.toBinaryString(EPOCH));
            System.out.println(Long.toBinaryString(EPOCH).length());
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 初始化workid*/
    private static void initWorkerId(){

        InetAddress address = getLocalAddress();
        byte[] ipAddressByteArr = address.getAddress();
        /**只保留低两位*/
        setWorkId((long)((ipAddressByteArr[ipAddressByteArr.length - 2] & 0B11) << Byte.SIZE +
                /** 只保留低八位数*/
                ipAddressByteArr[ipAddressByteArr.length - 1] & 0xFF));

    }

    private static InetAddress getLocalAddress(){
        try {
            Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();
            while (networkInterfaces.hasMoreElements()){
                NetworkInterface networkInterface = networkInterfaces.nextElement();
                if(!networkInterface.isUp() || networkInterface.isVirtual() || networkInterface.isLoopback()){
                    continue;
                }
                Enumeration<InetAddress> inetAddresses = networkInterface.getInetAddresses();
                while (inetAddresses.hasMoreElements()){
                    return inetAddresses.nextElement();
                }
            }
        } catch (SocketException e) {
            logger.debug("Error when getting ip host address: <{}>",e.getMessage());
            throw new IllegalStateException("Cannot get LocalHost InetAddress,please check your network!");
        }
        return null;
    }

    /**
     * 设置工作进程id*/
    private static void setWorkId(final Long workerId){
        Preconditions.checkArgument(workerId >= 0L && workerId <= WORKER_ID_MAX_VALUE);
        SnowFlakeGenerateIdWorker.workerId = workerId;
    }


    /**
     * 下一个id生成算法(序列id)
     * 生成链路唯一id*/
    public static long nextId(){
        long time = System.currentTimeMillis();
        /**如果当前时间小于上一次生成id时间戳 说明时钟回退 抛出异常*/
        Preconditions.checkArgument(time >= lastTime,"Clock is moving backwards,lastTime is %d,currentTime is %d",lastTime,time);
        /**如果是同一时间生成,进行毫秒内序列*/
        if(lastTime == time){
            /**毫秒内序列溢出*/
            if(0L == (sequence = ++ sequence & SEQUENCE_MASK)){
                /**阻塞到下一时间戳*/
                time = wailUntilNextTime(time);
            }
        }else {
            /**不同时间戳生成 序列值归零*/
            sequence = 0;
        }
        lastTime = time;
        if(logger.isDebugEnabled()){
            logger.debug("{}-{}-{}",new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date(lastTime)),workerId,sequence);
        }
        return (time - EPOCH) << TIMESTAMP_LEFT_SHIFT_BITS | workerId << WORKER_ID_LEFT_SHIFT_BITS | sequence;
    }

    private static long wailUntilNextTime(final long lastTime){
        long time = System.currentTimeMillis();
        while (time <= lastTime){
            time = System.currentTimeMillis();
        }
        return time;
    }
}
