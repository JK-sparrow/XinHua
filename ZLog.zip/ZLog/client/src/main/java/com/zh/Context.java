package com.zh;

import io.netty.channel.Channel;

/**
 * Context
 * @author wuweifeng wrote on 2019-12-05
 * @version 1.0
 */
public class Context {
    /**
     * APP_NAME
     */
    public static String APP_NAME;

    /**
     * 客户端发消息用的channel
     */
    public static Channel CHANNEL;


}
