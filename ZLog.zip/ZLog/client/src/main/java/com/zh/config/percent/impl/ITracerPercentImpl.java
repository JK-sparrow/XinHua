package com.zh.config.percent.impl;

import com.zh.config.percent.ITracerPercent;

public class ITracerPercentImpl implements ITracerPercent {
    @Override
    public Integer percent() {
        return 100;
    }
}
