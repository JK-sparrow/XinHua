package com.zh.udp;

/**
 * 单独发送大报文的bean*/
public class OneTracer {

    private byte[] bytes;

    public byte[] getBytes() {
        return bytes;
    }

    public void setBytes(byte[] bytes) {
        this.bytes = bytes;
    }
}
