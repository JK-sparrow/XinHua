package com.zh.filter;


import com.zh.Context;

import com.zh.config.percent.ITracerPercent;
import com.zh.config.percent.impl.ITracerPercentImpl;
import com.zh.config.tracerholder.TracerHolder;
import com.zh.platform.common.model.TracerBean;
import com.zh.platform.common.utils.ZstdUtils;
import com.zh.udp.UdpSender;
import com.zh.utils.IpUtils;
import com.zh.utils.SnowFlakeGenerateIdWorker;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

public class UserFilter implements Filter {

    private static final Logger logger = LoggerFactory.getLogger(UserFilter.class);

    /**
     * 获取切量百分比*/
    private ITracerPercent iTracerPercent;

    public UserFilter(ITracerPercent iTracerPercent) {
        this.iTracerPercent = iTracerPercent;
    }

    public UserFilter() {
        iTracerPercent = new ITracerPercentImpl();
    }

    public void setiTracerPercent(ITracerPercent iTracerPercent) {
        this.iTracerPercent = iTracerPercent;
    }

    /**
     * 传入百分比实现类*/

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

        HttpServletResponse httpServletResponse = (HttpServletResponse) response;
        HttpServletRequest httpServletRequest = (HttpServletRequest) request;
        String url = httpServletRequest.getRequestURI().replace("/","");
        long l = System.currentTimeMillis();
        Random random = new Random(l);
        //1-100之间
        int i = random.nextInt(100) + 1;
        if(iTracerPercent.percent() < i){
            chain.doFilter(request,response);
            return;
        }
        if(iTracerPercent.ignoreUriSet() != null && iTracerPercent.ignoreUriSet().contains(url)){
            chain.doFilter(request,response);
            return;
        }

        //链路唯一id
        long id = SnowFlakeGenerateIdWorker.nextId();
        TracerHolder.serTracerId(id);
        System.out.println("filter74:" + Thread.currentThread().getName());
        //传输对象基础属性设置
        TracerBean tracerBean = new TracerBean();
        tracerBean.setCreateTime(System.currentTimeMillis());
        List<Map<String,Object>> list = new ArrayList<>();
        tracerBean.setTracerObject(list);
        tracerBean.setTracerId(id + "");

        /**
         * 处理request的各个入参*/
        dealRequestMap(request,list,id,url);

        /**
         * 处理response*/
        dealResponseMap(response,request,httpServletResponse,list,chain);

        /**设置耗时*/
        tracerBean.setCostTime((int)(System.currentTimeMillis() - tracerBean.getCreateTime()));

        UdpSender.offerBean(tracerBean);


    }

    /**
     * 处理入参相关信息*/
    private void dealRequestMap(ServletRequest request,List<Map<String,Object>> list,long tracerId,String url){
        //request的各个入参
        Map<String,String[]> parameterMap = request.getParameterMap();
        //将request信息保存
        Map<String,Object> map = new HashMap<>();
        for (String s : parameterMap.keySet()) {
            map.put(s,parameterMap.get(s)[0]);
        }
        map.put("appName", Context.APP_NAME);
        map.put("serverIp", IpUtils.getIp());
        map.put("tracerId",tracerId);
        map.put("url",url);
        list.add(map);
    }

    /**
     * 处理出参相关信息*/
    private void dealResponseMap(ServletResponse response,ServletRequest request,HttpServletResponse resp,List<Map<String,Object>> list,FilterChain chain) throws IOException, ServletException {

        //包装响应对象并缓存响应数据
        ResponseWrapper responseWrapper = new ResponseWrapper(resp);

        chain.doFilter(request,responseWrapper);
        byte[] content = responseWrapper.getContent();
        String s = new String(content);

        //最终的要发往worker的response 经理base64压缩
        byte[] compress = ZstdUtils.compress(content);
        byte[] encode = Base64.getEncoder().encode(compress);

        Map<String,Object> map = new HashMap<>();
        map.put("response",encode);
        list.add(map);

        //对content做处理 再将content写入输出流
        response.setContentLength(-1);

        PrintWriter writer = response.getWriter();
        //writer.write("test");
        writer.write(s);
        writer.flush();
        writer.close();
    }

    @Override
    public void destroy() {

    }
}
