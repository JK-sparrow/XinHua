package com.zh.constant;

/**
 * 常用工具类constant*/
public class Constant {

    /**
     * netty通信端口*/
    public static int NETTY_PORT = 9999;
    /**
     * 冒号*/
    public static String SPLITER = ":";
    /**
     * 所有workers存这里*/
    public static String WORKER_PATH = "/zh/etcd/";

    /**
     * 当客户端要删除某个key 往etcd赋值该value 设置一秒过期*/
    public static String DEFAULT_DELETED_VALUE = "#[DELETED]";
}
