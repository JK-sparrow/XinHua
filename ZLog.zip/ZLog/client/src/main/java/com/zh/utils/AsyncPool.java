package com.zh.utils;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AsyncPool {

    private static ExecutorService executorService = Executors.newCachedThreadPool();

    public static void asyncDo(Runnable runnable){
        executorService.submit(runnable);
    }

    public static void shutDown(){
        executorService.shutdown();
    }
}
