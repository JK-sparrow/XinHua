package com.zh.udp;

import com.google.common.collect.Queues;
import com.zh.Context;

import com.zh.platform.common.model.RunLogMessage;
import com.zh.platform.common.model.TracerBean;
import com.zh.platform.common.model.TracerData;
import com.zh.utils.AsyncPool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

/**
 * udp对外发送消息*/
public class UdpSender {

    private static final Logger logger = LoggerFactory.getLogger(UdpSender.class);

    /**
     * 本地队列满了之后丢弃的数量*/
    private static AtomicLong FAIL_OFFER_COUNT  = new AtomicLong();

    /**
     * 本地队列已写入的总数量*/
    private static AtomicLong SUCCESS_OFFER_COUNT = new AtomicLong();

    /**
     * 本地logger队列已写入的总数量*/
    private static AtomicLong SUCCESS_LOGGER_OFFER_COUNT = new AtomicLong();

    /**
     * 出入参集中营 最多积压50000个*/
    private static LinkedBlockingQueue<TracerBean> tracerBeanQueue = new LinkedBlockingQueue<>();

    /**
     * 日志集中营 最大积压50000个*/
    private static LinkedBlockingQueue<RunLogMessage> logBeanQueue = new LinkedBlockingQueue<>();

    /**
     * 写入队列*/
    public static void offerBean(TracerBean tracerBean){

        boolean success = tracerBeanQueue.offer(tracerBean);
        if(!success){
            long failCount = FAIL_OFFER_COUNT.incrementAndGet();
            if(failCount % 10 == 0){
                logger.info("用户跟踪队列已满,当前丢弃数量:" + failCount);
            }
        }else {
            long successCount = SUCCESS_OFFER_COUNT.incrementAndGet();
            if(successCount % 1000 == 0){
                logger.info("用户跟踪已产生数量:" + successCount + "当前队列积压数量:" + tracerBeanQueue.size());
            }
        }
    }

    /**
     * 写入log队列*/
    public static void offerLogger(RunLogMessage runLogMessage){

        boolean success = logBeanQueue.offer(runLogMessage);
        if(!success){
            long failCount = FAIL_OFFER_COUNT.incrementAndGet();
            if(failCount % 10 == 0){
                logger.info("当前logger队列已满,当前丢弃数量:" + failCount);
            }
        }else {
            long successCount = SUCCESS_LOGGER_OFFER_COUNT.incrementAndGet();
            if(successCount % 1000 == 0){
                logger.info("用户logger已提交数量:" + successCount + "当前队列积压数量" + logBeanQueue.size());
            }
        }
    }

    /**
     * 定时往worker发送*/
    public static void upLoadToWorker(){

        AsyncPool.asyncDo(() -> {
            while (true){
                try {
                    if(tracerBeanQueue.isEmpty()) continue;
                    List<TracerBean> tempTracer = new ArrayList<>();
                    TracerBean poll = tracerBeanQueue.poll();
                    tempTracer.add(poll);
                    send(tempTracer);

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        //用户中途打的各日志
        AsyncPool.asyncDo(() -> {
            while (true){
                List<RunLogMessage> tempLogs = new ArrayList<>();
                try {
                    //要么key达到500个 要么每秒向worker提交一次
                    Queues.drain(logBeanQueue,tempLogs,500,1, TimeUnit.SECONDS);
                    if(tempLogs.isEmpty()){
                        continue;
                    }
                    List<TracerBean> tempTracer = new ArrayList<>();
                    TracerBean tracerBean = new TracerBean();
                    tracerBean.setTracerId("-9999");
                    List<Map<String,Object>> tracerObject = new ArrayList<>();
                    Map<String,Object> map = new HashMap<>();
                    for (RunLogMessage tempLog : tempLogs) {
                        map.put(UUID.randomUUID().toString(),tempLog);
                    }
                    tracerObject.add(map);
                    tracerBean.setTracerObject(tracerObject);
                    tempTracer.add(tracerBean);
                    send(tempTracer);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * 往worker发送tracerbean*/
    private static void send(List<TracerBean> tempTracer){

        TracerData tracerData = new TracerData();
        tracerData.setTracerBeanList(tempTracer);
        Context.CHANNEL.writeAndFlush(tracerData);
        System.out.println("UdpSender_131: 当前发送的udp数据包内容为 " + tracerData.toString());
    }
}




