package com.zh.config.appender;

import com.zh.config.tracerholder.TracerHolder;
import com.zh.platform.common.model.RunLogMessage;
import com.zh.udp.UdpSender;
import org.apache.logging.log4j.core.Filter;
import org.apache.logging.log4j.core.Layout;
import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.appender.AbstractAppender;
import org.apache.logging.log4j.core.config.plugins.Plugin;
import org.apache.logging.log4j.core.config.plugins.PluginAttribute;
import org.apache.logging.log4j.core.config.plugins.PluginElement;
import org.apache.logging.log4j.core.config.plugins.PluginFactory;
import org.apache.logging.log4j.core.layout.PatternLayout;

import java.io.Serializable;
import java.util.concurrent.Executors;

@Plugin(name = "tracer", category = "Core", elementType = "appender", printObject = true)
public class TracerLog4j2Appender extends AbstractAppender {

    @PluginFactory
    public static TracerLog4j2Appender createAppender(@PluginAttribute("name")String name,
                                                      @PluginElement("Filter")final Filter filter,
                                                      @PluginElement("Layout")Layout layout){
        if(name == null){
            LOGGER.error("No name provided for Tracerlog4j2Appender");
            return null;
        }
        if(layout == null){
            layout = PatternLayout.createDefaultLayout();
        }
        return new TracerLog4j2Appender(name,filter,layout);
    }

    protected TracerLog4j2Appender(String name, Filter filter, Layout<? extends Serializable> layout) {
        super(name, filter, layout);
    }

    @Override
    public void append(LogEvent logEvent) {

        long tracerId = TracerHolder.getTracerId();
        if(0L == tracerId){
            return;
        }
        System.out.println("log4j46:" + Thread.currentThread().getName());
        RunLogMessage logMessage = getLogMessage(logEvent);
        UdpSender.offerLogger(logMessage);
    }


    /**
     * 转化为对象*
     */
    private RunLogMessage getLogMessage(LogEvent logEvent){

         /* 设置链路唯一id*/
        RunLogMessage runLogMessage = new RunLogMessage();
        runLogMessage.setTracerId(TracerHolder.getTracerId());
        runLogMessage.setThreadName(logEvent.getThreadName());
        runLogMessage.setClassName(logEvent.getLoggerName());

        StackTraceElement source = logEvent.getSource();
        if(source != null){
            String methodName = source.getMethodName();
            int lineNumber = source.getLineNumber();
            runLogMessage.setMethodName(methodName + "(" + source.getFileName() + ":" + lineNumber + ")");
        }else {
            runLogMessage.setMethodName(logEvent.getThreadName());
        }

        runLogMessage.setLogLevel(logEvent.getLevel() + "");
        runLogMessage.setCreateTime(logEvent.getTimeMillis());
        runLogMessage.setContent(getMessage(logEvent));
        return runLogMessage;
    }

    /**
     * 日志正文信息*/
    private String getMessage(LogEvent logEvent){
        return logEvent.getMessage().getFormattedMessage();
    }
}
