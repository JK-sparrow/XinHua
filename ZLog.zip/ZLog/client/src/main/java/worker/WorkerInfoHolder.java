package worker;

import com.alibaba.fastjson.JSON;
import com.zh.utils.IpUtils;
import org.springframework.util.CollectionUtils;

import java.time.chrono.JapaneseChronology;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * 存储该客户端支持的worker列表*/
public class WorkerInfoHolder {

    /**
     * 保存worker的ip地址和channel的映射关系*/
    private static final List<String> WORKER_HOLDER = new CopyOnWriteArrayList<>();

    /**
     * 坐标*/
    private static int index = 0;

    /**
     * 发送到哪个worker 在这里跳一个*/
    public static String chooseWorker(){

        String workerIp = "127.0.0.1:9999";
        int size = WORKER_HOLDER.size();
        if(size == 0){
            return workerIp;
        }
        //按本机ip对worker地址进行哈希
        //int index = Math.abs(IpUtils.getIp().hashCode() % size);
        if(index >= size){
            index = 0;
        }
        workerIp = WORKER_HOLDER.get(index);
        index ++;
        return workerIp;
    }

    /**
     * 监听到worker信息变化后 将新worker信息与当前worker信息合并*/
    public static void mergeAndConnetcNew(List<String> allAddresses){
        if(CollectionUtils.isEmpty(allAddresses)){
            WORKER_HOLDER.clear();
            return;
        }
        //将新的进行排序
        Collections.sort(allAddresses);
        //如果相同 则什么也不干
        if(WORKER_HOLDER.equals(allAddresses)){
            return;
        }
        WORKER_HOLDER.clear();
        WORKER_HOLDER.addAll(allAddresses);

    }

}
