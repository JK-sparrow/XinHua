package com.zh.platform.dealfile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DealFileApplication {

    public static void main(String[] args) {
        SpringApplication.run(DealFileApplication.class,args);
    }
}
