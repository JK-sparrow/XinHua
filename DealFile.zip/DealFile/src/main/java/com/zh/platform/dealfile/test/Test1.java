package com.zh.platform.dealfile.test;

import com.zh.platform.dealfile.pool.AsyncPool;
import org.springframework.util.StringUtils;

import java.io.*;
import java.util.concurrent.CountDownLatch;
/**
 * @author zh
 * @date 22/4/22
 * @version 1.0
 * 去除文档中注释<!--注释内容-->*/
public class Test1 {

    private static final String FILE_PATH = "C:\\Users\\ywjk\\Desktop\\处理报文";

    public static void main(String[] args) {

        File folder = new File(FILE_PATH);
        if(folder.isDirectory()){
            File[] files = folder.listFiles();
            CountDownLatch countDownLatch = new CountDownLatch(files.length);
            for (File file : files) {
                AsyncPool.asyncDo(() -> {
                    try {
                        BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
                        File returnFile = new File(FILE_PATH + File.separator + file.getName().replace("请求", "处理"));
                        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(returnFile));
                        String s = "";
                        while ((s = bufferedReader.readLine()) != null){
                            if(s.contains("<!--")){
                                s = s.substring(0,s.indexOf("<!--")).trim();
                            }
                            bufferedWriter.write(s,0,s.length());
                        }
                        bufferedWriter.flush();
                        bufferedWriter.close();
                        bufferedReader.close();
                        file.delete();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    countDownLatch.countDown();
                });
            }
            try {
                countDownLatch.await();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
