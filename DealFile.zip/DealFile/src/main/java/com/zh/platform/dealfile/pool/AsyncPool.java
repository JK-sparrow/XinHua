package com.zh.platform.dealfile.pool;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AsyncPool {

    private static  ExecutorService executorService = Executors.newFixedThreadPool(10);

    public static void asyncDo(Runnable runnable){
        executorService.submit(runnable);
    }

    public static void shutdown(){
        executorService.shutdown();
    }
}
