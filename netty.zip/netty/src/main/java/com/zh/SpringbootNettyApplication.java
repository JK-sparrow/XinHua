package com.zh;

import com.zh.netty.server.NettyServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.net.InetSocketAddress;

@SpringBootApplication
public class SpringbootNettyApplication implements CommandLineRunner {

    private static final String SOCKET_IP = "127.0.0.1";
    private static final Integer SOCKET_PORI = 8888;
    private static final Logger logger = LoggerFactory.getLogger(SpringbootNettyApplication.class);

    @Autowired
    private NettyServer nettyServer;

    public static void main(String[] args) {
        SpringApplication.run(SpringbootNettyApplication.class,args);
    }

    @Override
    public void run(String... args) throws Exception {
        InetSocketAddress inetSocketAddress = new InetSocketAddress(SOCKET_IP, SOCKET_PORI);
        logger.info("netty服务器启动地址:" + SOCKET_IP);
        nettyServer.start(inetSocketAddress);
    }
}
