package com.zh.netty.client;

/**
 * 模拟多客户端发报文*/
public class TestNettyClient {

    public static void main(String[] args) {
        //开启10条线程 每个线程相对一个客户端
        for(int i = 0;i < 10;i ++){
            new Thread(new NettyClient("Thread" + "--" + i)).start();
        }
    }
}
