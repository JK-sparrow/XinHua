package com.zh.netty.server;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelId;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.handler.timeout.IdleState;
import io.netty.handler.timeout.IdleStateEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.util.concurrent.ConcurrentHashMap;

/**
 * netty服务端处理类*/
public class NettyServerHandler extends ChannelInboundHandlerAdapter {

    private static final Logger logger = LoggerFactory.getLogger(NettyServerHandler.class);
    //全局map 保存连接到服务端的通道数量
    private static final ConcurrentHashMap<ChannelId, ChannelHandlerContext> CHANNEL_MAP = new ConcurrentHashMap<>();

    /**
     * 有客户端连接服务器会触发此函数*/
    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
        InetSocketAddress inetSocketAddress = (InetSocketAddress) ctx.channel().remoteAddress();
        String clientIp = inetSocketAddress.getAddress().getHostAddress();
        int clientPort = inetSocketAddress.getPort();
        //获取连接通道唯一标识
        ChannelId id = ctx.channel().id();
        //如果map中不包含此连接 就保存连接
        if(CHANNEL_MAP.containsKey(id)){
            logger.info("客户端[" + id + "]是链接状态,链接客户端数量" + CHANNEL_MAP.size());
        }else {
            //保存链接
            CHANNEL_MAP.put(id,ctx);
            logger.info("客户端[" + id + "]链接netty服务器ip:" + clientIp + " port:" + clientPort);
            logger.info("链接客户端数量" + CHANNEL_MAP.size());
        }
    }

    /**
     * 有客户端终止链接服务器会触发此函数*/
    @Override
    public void channelInactive(ChannelHandlerContext ctx) throws Exception {
        InetSocketAddress inetSocketAddress = (InetSocketAddress) ctx.channel().remoteAddress();
        String clientIp = inetSocketAddress.getAddress().getHostAddress();
        int clientPort = inetSocketAddress.getPort();
        ChannelId id = ctx.channel().id();
        if(CHANNEL_MAP.containsKey(id)){
            //删除链接
            CHANNEL_MAP.remove(id);
            logger.info("客户端[" + id + "]退出netty服务器[ip:" + clientIp + " port:" + clientPort);
            logger.info("链接通道数量" + CHANNEL_MAP.size());
        }
    }

    /**
     * 有客户端发消息会触发此函数*/
    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        InetSocketAddress inetSocketAddress = (InetSocketAddress) ctx.channel().remoteAddress();
        String clientIp = inetSocketAddress.getAddress().getHostAddress();
        int clientPort = inetSocketAddress.getPort();
        ChannelId id = ctx.channel().id();
        logger.info("加载客户端报文...");
        logger.info("[" + id + "] :" + msg);

        /**
         * 下面可以解析数据,保存数据,生产返回报文,将需要返回的报文写入writer函数*/


        //响应客户端
        this.channelWrite(id,msg);
    }

    /**
     * 服务端给客户端发送消息*/

    public void channelWrite(ChannelId id,Object msg){

        ChannelHandlerContext channelHandlerContext = CHANNEL_MAP.get(id);
        if(channelHandlerContext == null){
            logger.info("通道[" + id + "]不存在");
            return;
        }
        if(msg == null || msg == ""){
            logger.info("服务端响应空的消息");
            return;
        }
        channelHandlerContext.write(msg);
        channelHandlerContext.flush();
    }

    @Override
    public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {

        String socketString = ctx.channel().remoteAddress().toString();
        if(evt instanceof IdleStateEvent){
            IdleStateEvent evt1 = (IdleStateEvent) evt;
            if(evt1.state() == IdleState.READER_IDLE){
                logger.info("client :" + socketString + "读超时");
                ctx.disconnect();
            }else if(evt1.state() == IdleState.WRITER_IDLE){
                logger.info("client :" + socketString + "写超时");
                ctx.disconnect();
            }else if(evt1.state() == IdleState.ALL_IDLE){
                logger.info("client :" + socketString + "总超时");
                ctx.disconnect();
            }
        }
    }

    /**
     * 发生异常会触发此函数*/
    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        ctx.close();
        logger.info(ctx.channel().id() + "发生了错误,此链接被关闭,当前链接通道数量为" + CHANNEL_MAP.size());
    }
}
