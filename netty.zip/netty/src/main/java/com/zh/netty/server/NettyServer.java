package com.zh.netty.server;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelOption;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.net.InetSocketAddress;

@Component
public class NettyServer {

    private static final Logger logger = LoggerFactory.getLogger(NettyServer.class);
    public void start(InetSocketAddress address) throws InterruptedException {
        //配置服务端的nio线程组
        NioEventLoopGroup bossGroup = new NioEventLoopGroup(1);
        NioEventLoopGroup workerGroup = new NioEventLoopGroup();

        ServerBootstrap serverBootstrap = new ServerBootstrap()
                .group(bossGroup, workerGroup) //绑定线程池
                .channel(NioServerSocketChannel.class)
                .localAddress(address)
                .childHandler(new NettyServerChannelInitializer()) //编码解码
                .option(ChannelOption.SO_BACKLOG, 128) //服务端接受链接的队列长度,如果队列已满,客户端链接将被拒绝
                .childOption(ChannelOption.SO_KEEPALIVE, true);//保持长链接 2小时无数据激活心跳机制

        //绑定端口 开始接收进来的链接
        ChannelFuture sync = serverBootstrap.bind(address).sync();
        logger.info("netty服务器开始监听端口" + address.getPort());
        //关闭channel和块,直到它被关闭
        sync.channel().closeFuture().sync();
    }
}
