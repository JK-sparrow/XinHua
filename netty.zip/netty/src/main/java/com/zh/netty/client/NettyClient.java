package com.zh.netty.client;

import io.netty.bootstrap.Bootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelOption;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.codec.string.StringDecoder;
import io.netty.handler.codec.string.StringEncoder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;

public class NettyClient implements Runnable {

    private static final Logger logger = LoggerFactory.getLogger(NettyClient.class);
    private static final String HOST = System.getProperty("host","127.0.0.1");
    private static final int PORT = Integer.parseInt(System.getProperty("port","8888"));
    private static final int SIZE = Integer.parseInt(System.getProperty("size","256"));

    private String content;

    public NettyClient(String content) {
        this.content = content;
    }

    @Override
    public void run() {

        //configure this client
        NioEventLoopGroup group = new NioEventLoopGroup();

        int num = 0;
        boolean flag = true;

        Bootstrap bootstrap = new Bootstrap();
        bootstrap.group(group)
                .channel(NioSocketChannel.class)
                .option(ChannelOption.TCP_NODELAY,true)
                .handler(new NettyClientChannelInitializer(){
                    @Override
                    protected void initChannel(SocketChannel socketChannel) throws Exception {
                        ChannelPipeline pipeline = socketChannel.pipeline();
                        pipeline.addLast("decoder",new StringDecoder());
                        pipeline.addLast("encoder",new StringEncoder());
                        pipeline.addLast(new NettyClientHandler());
                    }
                });
        try {
            ChannelFuture future = bootstrap.connect(HOST, PORT).sync();
            while (flag){
                num ++;
                future.channel().writeAndFlush(content + "--" + LocalDateTime.now());
                Thread.sleep(3000);
                if(num == 100){
                    flag = false;
                }
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            group.shutdownGracefully();
        }
        logger.info(content + "--------------------------------------" + num);

    }
}
