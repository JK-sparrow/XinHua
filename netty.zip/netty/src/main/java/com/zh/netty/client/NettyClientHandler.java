package com.zh.netty.client;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelId;
import io.netty.channel.ChannelInboundHandlerAdapter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.unit.DataUnit;

import java.time.LocalDateTime;
import java.util.concurrent.ConcurrentHashMap;

public class NettyClientHandler extends ChannelInboundHandlerAdapter {

    /**
     * 计算有多少客户端接入 第一个string为客户端ip*/
    private static final Logger logger = LoggerFactory.getLogger(NettyClientHandler.class);
    private static final ConcurrentHashMap<ChannelId, ChannelHandlerContext> CLIENT_MAP = new ConcurrentHashMap<>();

    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {

        CLIENT_MAP.put(ctx.channel().id(),ctx);
        logger.info("ClientHandler active");
    }

    /**
     * 服务端终止链接会触发此函数*/
    @Override
    public void channelInactive(ChannelHandlerContext ctx) throws Exception {
        ctx.close();
        logger.info("服务终止了链接");
    }

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        logger.info("回写数据" + msg);
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        logger.info("服务端发生异常[" + cause.getMessage() + "]");
        ctx.close();
    }

    /**
     * 客户端给服务端发送消息*/
    public void channelWrite(ChannelId id,Object msg){

        ChannelHandlerContext channelHandlerContext = CLIENT_MAP.get(id);
        if(channelHandlerContext == null){
            logger.info("通道[" + id + "]数据不存在");
            return;
        }

        //将客户端信息直接返回写入ctx
        channelHandlerContext.write(msg + "时间:" + LocalDateTime.now());
        //刷新缓存区
        channelHandlerContext.flush();
    }
}
