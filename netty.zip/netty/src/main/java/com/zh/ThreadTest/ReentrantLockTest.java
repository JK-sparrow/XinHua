package com.zh.ThreadTest;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class ReentrantLockTest {

    static double year;
    public static void main(String[] args) {

        //实例化一个锁和condition
        ReentrantLock reentrantLock = new ReentrantLock();
        Condition condition = reentrantLock.newCondition();

        Thread threadA = new Thread(() -> {
            reentrantLock.lock();
            try {
            for(year = 0;year <= 5;year += 0.5){
                System.out.println("开始练习唱跳rap,已经练习" + year + "年");

                    Thread.sleep(1000);
                    if(year == 2.5){
                        condition.signal();
                        break;
                    }
            }
            } catch (InterruptedException e) {
                e.printStackTrace();
            } finally {
                reentrantLock.unlock();
            }
        });

        Thread threadB = new Thread(() -> {

            reentrantLock.lock();
            try {
                condition.await();
                System.out.println("开始练习打篮球");
            } catch (InterruptedException e) {
                e.printStackTrace();
            } finally {
                reentrantLock.unlock();
            }
        });

        threadB.start();
        threadA.start();
    }
}
