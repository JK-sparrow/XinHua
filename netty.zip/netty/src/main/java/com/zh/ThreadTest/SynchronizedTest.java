package com.zh.ThreadTest;

public class SynchronizedTest {

    static double year;
    public static void main(String[] args) {

        SynchronizedTest synchronizedTest = new SynchronizedTest();
        synchronizedTest.execute();
    }

    public void execute(){
        Thread threadA = new Thread(() -> {
            synchronized (this){
                for(year = 0;year <= 5;year += 0.5){
                    System.out.println("开始练习唱跳rap,已经练习" + year + "年");
                    try {
                        Thread.sleep(1000);
                        if(year == 2.5){
                            System.out.println("练习时长两年半");
                            notify();
                            break;
                        }
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        Thread threadB = new Thread(() -> {
            synchronized (this){
                System.out.println(1);
                try {
                    wait();
                    System.out.println("开始练习打篮球");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            });

        threadB.start();
        threadA.start();
    }
}
