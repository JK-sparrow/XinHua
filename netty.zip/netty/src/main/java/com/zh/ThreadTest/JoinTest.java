package com.zh.ThreadTest;

public class JoinTest {

    static double year;

    public static void main(String[] args) {


        //线程A 练习唱 跳 Rap
        Thread threadA = new Thread(() -> {
            for(year = 0;year <= 5;year += 0.5){
                System.out.println("开始练习唱跳rap,已练习" + year + "年");
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                if(year == 2.5){
                    System.out.println("练习时长两年半");
                    break;
                }
            }
        });

        Thread threadB = new Thread(() -> {
            System.out.println(1);
            try {
                threadA.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("开始练习打篮球");
        });

        threadA.start();
        threadB.start();
    }
}
