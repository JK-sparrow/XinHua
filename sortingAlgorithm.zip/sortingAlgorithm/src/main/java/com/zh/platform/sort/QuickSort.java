package com.zh.platform.sort;

import com.alibaba.fastjson.JSON;

/**
 * 快速排序
 * @author zh
 * @date 2022/3/11
 * O(nlogn)
 * */
public class QuickSort {

    public static void main(String[] args) {


        //冒泡进阶
        int[] arr = {3,2,1,4,5,6,7,9,8,10};
        System.out.println(JSON.toJSON(quickSort(arr,0,arr.length - 1)));
    }

    private static int[] quickSort(int[] arr,int left,int right){

        //分治
        if (left < right){
            int privotpos = partition(arr,left,right);
            quickSort(arr,left,privotpos - 1);
            quickSort(arr,privotpos + 1,right);
        }
        return arr;

    }

    private static int partition(int[] arr,int left,int right){

        int mid = left + (right - left) / 2;

        int tmp = arr[left];
        arr[left] = arr[mid];
        arr[mid] = tmp;

        int privot = arr[left];
        while (left < right){
            while (left < right && arr[right] >= privot) right --;
            arr[left] = arr[right];
            while (left < right && arr[left] <= privot) left ++;
            arr[right] = arr[left];
        }
        arr[left] = privot;
        return left;
    }
}
