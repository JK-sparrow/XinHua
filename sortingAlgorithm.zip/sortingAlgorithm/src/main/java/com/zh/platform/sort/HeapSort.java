package com.zh.platform.sort;

import com.alibaba.fastjson.JSON;

/**
 * 堆排序
 * @author zh
 * @date 2022/3/11
 * O(nlogn)
 * */
public class HeapSort {

    public static void main(String[] args) {

        //每次堆调整堆顶为最大值 交换堆顶元素与堆尾元素 '去掉'堆尾继续进行调整..
        int[] arr = {3,2,1,4,5,6,7,9,8,10};
        System.out.println(JSON.toJSON(heapSort(arr)));
    }

    private static int[] heapSort(int[] arr){

        int length = arr.length;
        //初始化堆 构造一个最大堆
        for(int i = length / 2 - 1;i >= 0;i --){
            heapAdjust(arr,i,length);
        }

        //将堆顶元素和最后一个元素交换 并重新调整
        for(int i = arr.length - 1;i > 0;i --){
            int tmp = arr[i];
            arr[i] = arr[0];
            arr[0] = tmp;
            heapAdjust(arr,0,i);
        }
        return arr;
    }

    private static void heapAdjust(int[] arr,int index,int length){

        int max = index;
        int left = index * 2;
        int right = index * 2 + 1;
        if(left < length && arr[index] < arr[left]){
            index = left;
        }
        if(right < length && arr[index] < arr[right]){
            index = right;
        }
        if(index != max){
            int tmp = arr[index];
            arr[index] = arr[max];
            arr[max] = tmp;
            heapAdjust(arr,index,length);
        }
    }
}
