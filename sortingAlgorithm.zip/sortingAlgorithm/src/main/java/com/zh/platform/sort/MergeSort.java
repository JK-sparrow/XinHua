package com.zh.platform.sort;

import com.alibaba.fastjson.JSON;

import java.util.Arrays;

/**
 * 归并排序
 * @author zh
 * @date 2022/3/10
 * O(nlogn)
 * */
public class MergeSort {

    public static void main(String[] args) {

        int[] arr = {3,2,1,4,5,6,7,9,8,10};
        System.out.println(JSON.toJSON(mergeSort(arr)));
    }

    private static int[] mergeSort(int[] arr){

        //分治
        if(arr.length < 2) return arr;
        int length = arr.length;
        int mid = length / 2;
        return merge(mergeSort(Arrays.copyOfRange(arr,0,mid)),mergeSort(Arrays.copyOfRange(arr,mid,arr.length)));
    }

    private static int[] merge(int[] left,int[] right){

        int[] res = new int[left.length + right.length];
        for(int i = 0,j = 0,index = 0;index < res.length;index ++){
            if(i >= left.length){
                res[index] = right[j ++];
            }else if(j >= right.length){
                res[index] = left[i ++];
            }else if(left[i] < right[j]){
                res[index] = left[i ++];
            }else {
                res[index] = right[j ++];
            }
        }
        return res;
    }
}
