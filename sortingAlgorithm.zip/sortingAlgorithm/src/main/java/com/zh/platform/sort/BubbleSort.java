package com.zh.platform.sort;

import com.alibaba.fastjson.JSON;

/**
 * 冒泡排序
 * @author zh
 * @date 2022/3/10
 * O(n) O(n^2)
 * */

public class BubbleSort {

    public static void main(String[] args) {

        int[] arr = {3,2,1,4,5,6,7,9,8,10};
        System.out.println(JSON.toJSON(bubbleSort(arr)));

    }

    private static int[] bubbleSort(int[] arr){

        //每次将最大数冒(两两比较交换)到数组尾
        for(int i = 0;i < arr.length;i ++){
            for(int j = 0;j < arr.length - 1 - i;j ++){
                if(arr[j] > arr[j + 1]){
                    int tmp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = tmp;
                }
            }
        }
        return arr;
    }
}
