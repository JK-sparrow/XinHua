package com.zh.platform.sort;

import com.alibaba.fastjson.JSON;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 桶排序
 * @author zh
 * @date 2022/3/11
 * O(n ^ 2)
 * */
public class BucketSort {

    public static void main(String[] args) {

        int[] arr = {3,2,1,4,5,6,7,9,8,10};
        System.out.println(JSON.toJSON(bucketSort(arr,5)));
    }

    private static int[] bucketSort(int[] arr,int bucketSize){

        int max = Arrays.stream(arr).max().getAsInt();
        int min = Arrays.stream(arr).min().getAsInt();
        List<Integer> res = new ArrayList<>();

        int bucketCount = (max - min) / bucketSize + 1;
        List<List<Integer>> lists = new ArrayList<>();
        for(int i = 0;i < bucketCount;i ++){
            //构造桶
            List<Integer> bucket = new ArrayList<>();
            lists.add(bucket);

        }
        for(int i = 0;i < arr.length;i ++){
            //往桶里塞元素
            lists.get((arr[i] - min) / bucketSize).add(arr[i]);
        }

        for(int i = 0;i < bucketCount;i ++){
            if(bucketSize == 1){
                for(int m = 0;m < lists.get(i).size();m ++){
                    res.add(lists.get(i).get(m));
                }
            }else {
                if(bucketCount == 1) bucketSize --;
                int size = lists.get(i).size();
                int[] tmpArr = new int[size];
                for(int k = 0;k < size;k ++){
                    tmpArr[k] = lists.get(i).get(k);
                }
                int[] intrealArr = bucketSort(tmpArr, bucketSize);
                for (int i1 : intrealArr) {
                    res.add(i1);
                }
            }
        }
        for(int i = 0;i < res.size();i ++){
            arr[i] = res.get(i);
        }
        return arr;
    }
}
