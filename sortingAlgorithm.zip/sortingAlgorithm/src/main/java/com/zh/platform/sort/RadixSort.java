package com.zh.platform.sort;

import com.alibaba.fastjson.JSON;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 基数排序
 * @author zh
 * @date 2022/3/11
 * O(n * k(最大数位数))
 * */
public class RadixSort {

    public static void main(String[] args) {

        int[] arr = {13,22,111,24,52,6,7,9,8,10};
        System.out.println(JSON.toJSON(radixSort(arr)));

    }

    private static int[] radixSort(int[] arr){

        int max = Arrays.stream(arr).max().getAsInt();
        int length = (max + "").length();
        List<Integer> list = new ArrayList<>();
        for(int i = 0;i < arr.length;i ++){
            list.add(arr[i]);
        }
        List<List<Integer>> lists = new ArrayList<>();
        for(int i = 0;i < 10;i ++){
            lists.add(new ArrayList<>());
        }
        int mod = 10;
        int div = 1;
        while (length > 0){
            for (Integer integer : list) {
                lists.get((integer % mod) / div).add(integer);
            }
            list.clear();
            for (List<Integer> integers : lists) {
                for (Integer integer : integers) {
                    list.add(integer);
                }
                integers.clear();
            }
            mod *= 10;
            div *= 10;
            length --;
        }
        for(int i = 0;i < list.size();i ++){
            arr[i] = list.get(i);
        }
        return arr;

    }
}
