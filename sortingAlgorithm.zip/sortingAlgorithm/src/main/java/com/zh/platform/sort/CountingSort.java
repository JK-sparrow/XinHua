package com.zh.platform.sort;

import com.alibaba.fastjson.JSON;

import java.util.Arrays;

/**
 * 计数排序
 * @author zh
 * @date 2022/3/11
 * O(n+k(最大数))
 * */
public class CountingSort {

    public static void main(String[] args) {

        //开辟额外空间索引对应数字 统计完成依次放入数组
        int[] arr = {3,2,1,4,5,6,7,9,8,10};
        System.out.println(JSON.toJSON(countingSort(arr)));
    }

    private static int[] countingSort(int[] arr){

        int max = Arrays.stream(arr).max().getAsInt();

        int[] tmp = new int[max + 1];

        for (int i : arr) {
            tmp[i] ++;
        }
        int j = 0;
        for(int i = 0;i < tmp.length;i ++){
            if(tmp[i] == 1) arr[j ++] = i;
        }
        return arr;
    }
}
