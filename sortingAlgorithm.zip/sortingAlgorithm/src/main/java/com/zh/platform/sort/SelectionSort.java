package com.zh.platform.sort;

import com.alibaba.fastjson.JSON;

/**
 * 选择排序
 * @author zh
 * @date 2022/3/10
 * O(n^2)
 * */
public class SelectionSort {

    public static void main(String[] args) {

        int[] arr = {3,2,1,4,5,6,7,9,8,10};
        System.out.println(JSON.toJSON(selectionSort(arr)));
    }

    private static int[] selectionSort(int[] arr){

        //遍历获取最小元素索引 最后交换
        for(int i = 0;i < arr.length;i ++){
            int minIndex = i;
            for(int j = i;j < arr.length;j ++){
                if(arr[j] < arr[minIndex]) minIndex = j;
            }
            int tmp = arr[minIndex];
            arr[minIndex] = arr[i];
            arr[i] = tmp;
        }
        return arr;
    }
}
