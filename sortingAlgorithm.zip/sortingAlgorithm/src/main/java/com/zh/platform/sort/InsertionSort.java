package com.zh.platform.sort;

import com.alibaba.fastjson.JSON;

/**
 * 插入排序
 * @author zh
 * @date 2022/3/10
 * O(n^2)
 * */
public class InsertionSort {

    public static void main(String[] args) {

        int[] arr = {3,2,1,4,5,6,7,9,8,10};
        System.out.println(JSON.toJSON(InsertionSort(arr)));
    }

    private static int[] InsertionSort(int[] arr){

        //每次将一个未排序元素插入到已排序队列中
        for(int i = 0;i < arr.length;i ++){
            int cur = arr[i];
            int index = i;
            for(int j = i - 1;j >= 0;j --){
                if(cur < arr[j]){
                    arr[index --] = arr[j];
                }
            }
            arr[index] = cur;
        }
        return arr;
    }
}
