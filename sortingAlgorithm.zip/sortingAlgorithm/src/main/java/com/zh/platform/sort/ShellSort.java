package com.zh.platform.sort;

import com.alibaba.fastjson.JSON;

/**
 * 希尔排序
 * @author zh
 * @date 2022/3/10
 * O(nlog2n)
 * */
public class ShellSort {

    public static void main(String[] args) {

        int[] arr = {3,2,1,4,5,6,7,9,8,10};
        System.out.println(JSON.toJSON(shellSort(arr)));
    }

    private static int[] shellSort(int[] arr){

        //插入排序进阶变形
        int length = arr.length;
        int gap = length / 2;
        while (gap > 0){

            for(int i = gap;i < arr.length;i ++){
                int cur = arr[i];
                int index = i;
                for(int j = i - gap;j >= 0;j -= gap){
                    if(cur < arr[j]){
                        arr[index] = arr[j];
                        index -= gap;
                    }
                }
                arr[index] = cur;
            }
            gap /= 2;
        }
        return arr;
    }
}
