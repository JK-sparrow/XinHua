package com.zh.platfrom.apollo.schedual;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@EnableScheduling
@Component
public class ApolloParamTest {


    @Value("${test.value}")
    private String value;

    @Scheduled(fixedRate = 5000)
    private void test(){
        System.out.println("value:" + value);
    }
}
