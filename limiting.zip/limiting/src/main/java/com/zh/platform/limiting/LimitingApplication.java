package com.zh.platform.limiting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LimitingApplication {

    public static void main(String[] args) {
        SpringApplication.run(LimitingApplication.class,args);
    }
}
