/*
package com.zh.platform.limiting.config;

import com.alibaba.csp.sentinel.annotation.aspectj.SentinelResourceAspect;
import com.alibaba.csp.sentinel.slots.block.RuleConstant;
import com.alibaba.csp.sentinel.slots.block.flow.FlowRule;
import com.alibaba.csp.sentinel.slots.block.flow.FlowRuleManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;

@Configuration
public class SentinelConfig {

    @Bean
    public SentinelResourceAspect sentinelResourceAspect(){
        return new SentinelResourceAspect();
    }

    @PostConstruct
    private void initRules(){
        FlowRule test1Rule = new FlowRule();
        test1Rule.setResource("test1Rule");
        test1Rule.setControlBehavior(RuleConstant.CONTROL_BEHAVIOR_WARM_UP);
        test1Rule.setGrade(RuleConstant.FLOW_GRADE_QPS);
        test1Rule.setCount(10);
        test1Rule.setWarmUpPeriodSec(10);
        List<FlowRule> flowRuleList = new ArrayList<>();
        flowRuleList.add(test1Rule);
        FlowRuleManager.loadRules(flowRuleList);

    }
}
*/
