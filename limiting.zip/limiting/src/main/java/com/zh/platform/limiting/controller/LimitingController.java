package com.zh.platform.limiting.controller;

import com.alibaba.csp.sentinel.annotation.SentinelResource;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/limiting")
public class LimitingController {


    @RequestMapping("/test1")
    @SentinelResource(value = "test1Rule")
    public String test1(){
        return "成功";
    }
}
